# mem_vf testbench'ini DSim'de derle + calistir (mem_vf kokunden calistir)
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force
. "C:\Program Files\Altair\DSim\2026\shell_activate.ps1"
$env:DSIM_LICENSE = "C:\Users\betul\AppData\Local\metrics-ca\dsim-license.json"
dsim -sv -uvm 1.2 -timescale 1ns/1ns -f filelist.f -top tbench_top +UVM_TESTNAME=mem_base_test +acc+b -waves waves.mxd
